#!/bin/bash
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# This will backup your influxdb
# Without changing anything it will backup a database called 'clx_statd' to a
#  directory called 'influx_clx_statd_backup' in the directory where the 
#  script is run from
#---------------------------------------------------------------------------

backup_dir='.'
backup_name="influx_clx_statd_backup"
influx_db='clx_statd'

dt=`date "+%Y%m%d_%H%M%S"`
/usr/bin/influxd backup -database $influx_db $backup_dir/$backup_name.$dt
