#!/usr/bin/python
'''
Read data from clustrix_statd and load into influxdb

The process is so simple that most of this code is just for printing logs
'''

import MySQLdb
from influxdb import InfluxDBClient
from datetime import datetime
import time
import logging
import sys
from optparse import OptionParser

stat_name_by_id = {}

def custom_logger(name, logger_level):
    logger_level = logger_level.upper()
    formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s',
                                  datefmt='%Y-%m-%d %H:%M:%S')
    logger = logging.getLogger(name)
    logger.setLevel(logging.getLevelName(logger_level))
    try:
        # Not clear why this has a log file, or why it requires root to write
        #   to the log file.
        handler = logging.FileHandler('/var/log/influx_load.log', mode='a')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    except Exception as e:
        print "Error opening log file: %s" % e
    screen_handler = logging.StreamHandler(stream=sys.stdout)
    screen_handler.setFormatter(formatter)
    logger.addHandler(screen_handler)
    return logger

def update_last_run(influx, cluster_name, logger, row):
    '''Overly complex way to get Influx to store the two values which track how
    far the Clustrix Statd import has progressed.'''

    stat_id, timestamp, _ = row

    logger.info("Updating last run with id='%s' and timestamp='%s'" % (stat_id, timestamp))
    rc = influx.write_points([{
            "measurement": "last_run",
            "time_precision": 's',
            "time": "1970-01-01T00:00:00",
            "tags":{
                "cluster_name": "%s" % cluster_name,
            },
            "fields": {
                "last_dt": "%s" % timestamp,
                "last_id": stat_id,
            }}])

    if not rc:
        logger.error("Could not write to influxdb (rc %s). Exiting" % rc)
        exit(1)

    return stat_id, timestamp

def get_last_run(influx, logger, cluster_name):
    '''equivalently complex method of reading the two values we stored
    Only used once on startup, to pick up where the last run left off.'''

    sql = "select * from last_run where time = 0 and cluster_name='%s'" % cluster_name
    try:
        result = influx.query(sql)
    except Exception as err:
        logger.error("last_run read failed: %d: %s" % (err.args[0], err.args[1]))
        logger.error("sql='%s'" % sql)
        exit (1)

    if not result:
        return ('1970-01-01 00:00:00', 0)
    else:
        row = result.items()[0][1].next()
        return row['last_id'], row['last_dt']

def stat_name_cache(statd_id, statd_c, logger):
    '''Cache stat id -> name values to minimize db lookups'''
    if statd_id in stat_name_by_id:
        return stat_name_by_id[statd_id]
    try:
        statd_c.execute("select name from statd_metadata where id = %s", (statd_id,))
    except MySQLdb.Error as err:
        logger.error("Error %d: %s" % (err.args[0], err.args[1]))
        exit(1)
    return statd_c.fetchone()[0]

def sample_to_point(row, statd_c, cluster_name, logger):
    '''take a statd sample and return a dict representing an influx point'''
    stat_id, timestamp, value = row
    return {"measurement": stat_name_cache(stat_id, statd_c, logger),
            "time_precision": 's',
            "time": '%s' % timestamp,
            "tags": {
                "cluster_name": "%s" % cluster_name
            },
            "fields": {
                "id": stat_id,
                "value": value
            }}

def maybe_create_influx_db(influx, influx_db, logger):
    if influx_db not in [db['name'] for db in influx.get_list_database()]:
        result = influx.create_database(influx_db)
        if result:
            logger.error("Could not create database '%s'. Exiting!" % influx_db)
            exit(1)

def main():
    parser = OptionParser()
    parser.add_option("--influx-db", dest="influx_db",
                      help="Influx database name to load data into")
    parser.add_option("--clxdb-host", dest="clxdb_host",
                      help="Clustrix RDBMS instance to monitor")
    parser.add_option("--rows-to-read", dest="rows_to_read",
                      help="Rows to read from Clustrix Statd per time interval [Default=%default]", default=10000)
    parser.add_option("--wait-time-s", dest="wait_time_s", type='int',
                      help="Time to wait between Clustrix Statd reads [Default=%default]", default=30)
    parser.add_option("--sql-user", dest="sql_user",
                      help="User name to connect to Clustrix")
    parser.add_option("--sql-passwd", dest="sql_passwd",
                      help="Password for user", default="")
    parser.add_option("--influxdb-host", dest="influxdb_host",
                      help="Host where influxdb is located [Default=%default]", default="localhost")
    parser.add_option("--influxdb-port", dest="influxdb_port",
                      help="Port for influxdb [default=%default]", default=8086)
    parser.add_option("--logger-level", dest="logger_level",
                      help="Log level: ERROR, WARNING, INFO, DEBUG [Default=%default]", default="ERROR")
    parser.add_option("--cluster-name", dest="cluster_name", help="Tag data with cluster name")

    opts, args = parser.parse_args()
    if not opts.clxdb_host:
        parser.error('--clxdb-host is required')
    if not opts.influx_db:
        parser.error('--influx-db is required')
    if not opts.sql_user:
        parser.error('--sql-user is required')

    #Setup custom logging
    logger = custom_logger('influxdb_load', opts.logger_level)

    #Connect to influxdb
    logger.info("Trying to connect to influxdb on host '%s'." % opts.influxdb_host)
    try:
        influx = InfluxDBClient(opts.influxdb_host, opts.influxdb_port)
    except Exception as e:
        logger.error("Could not connect to influxdb on host '%s'." % opts.influxdb_host)
        logger.error(e)
        exit(1)

    maybe_create_influx_db(influx, opts.influx_db, logger)
    result = influx.switch_database(opts.influx_db)
    if result is not None:
        logger.error(result)
        logger.error("Could not connect to influxdb '%s'. Exiting" % opts.influx_db)
        exit(1)

    #Connect to statd database
    try:
        statd_db = MySQLdb.connect(host=opts.clxdb_host, user=opts.sql_user, db='clustrix_statd',
                                    passwd=opts.sql_passwd, autocommit=True)
        statd_c = statd_db.cursor()
    except MySQLdb.Error as e:
        logger.error("Error %d: %s" % (e.args[0], e.args[1]))
        exit(1)

    cluster_name = opts.cluster_name
    if not cluster_name:
        #Get the global variable cluster_name
        try:
            statd_c.execute("select @@cluster_name")
            cluster_name = statd_c.fetchone()[0]
        except MySQLdb.Error as err:
            logger.error("Error %d: %s" % (err.args[0], err.args[1]))
            exit(1)
    logger.debug("cluster_name = '%s'" % cluster_name)

    # Warm up the stat name cache:
    statd_c.execute('select id, name from clustrix_statd.statd_metadata')
    for stat_id, stat_name in statd_c.fetchall():
        stat_name_by_id[stat_id] = stat_name

    last_id = None
    last_time = None
    while True:

        if not last_id or not last_time:
            last_id, last_time = get_last_run(influx, logger, cluster_name)
        logger.info("Last date is '%s' and last id is '%s'" % (last_time, last_id))

        # Attempt to find stats in the last timestamp, over the last id, in case we
        #   did not read a complete sample set in the last run
        sql = ("SELECT id, timestamp, value"
               "  FROM clustrix_statd.statd_history"
               "  WHERE timestamp = '%s' and id > %s"
               "  ORDER BY timestamp, id ASC"
               "  LIMIT %s" % (last_time, last_id, opts.rows_to_read))
        logger.debug(sql)

        try:
            statd_c.execute(sql)
        except MySQLdb.Error as err:
            logger.error("Error %d: %s" % (err.args[0], err.args[1]))
            logger.error("sql: '%s'" % sql)
            exit(1)

        rows = statd_c.fetchall()

        if len(rows) < opts.rows_to_read:
            # The last select did not get enough rows, add more
            sql = ("SELECT id, timestamp, value"
                    "  FROM clustrix_statd.statd_history"
                    "  WHERE timestamp > '%s'"
                    "  ORDER BY timestamp, id ASC"
                    "  LIMIT %s" % (last_time, opts.rows_to_read-len(rows)))
            logger.debug(sql)
            try:
                statd_c.execute(sql)
                rows += statd_c.fetchall()
            except MySQLdb.Error as err:
                logger.error("Error %d: %s" % (err.args[0], err.args[1]))
                logger.error("sql: '%s'" % sql)
                exit(1)

        # Convert rows to influx points and write them
        if rows:
            points = [sample_to_point(row, statd_c, cluster_name, logger) for row in rows]
            logger.info("Starting to load influxdb with %s rows" % len(rows))
            try:
                influx.write_points(points)
            except Exception as e:
                logger.error("Series insert failed. %s" % e)
                exit(1)

            last_id, last_time = update_last_run(influx, cluster_name, logger, rows[-1])

        logger.info("Sleeping for %s seconds" % opts.wait_time_s)
        time.sleep(opts.wait_time_s)

if __name__ == "__main__":
    main()
